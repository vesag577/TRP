import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ScenarioSection from './components/ScenarioSection';
import ResearchSection from './components/ResearchSection';
import AboutSection from './components/AboutSection';
import Footer from './components/Footer';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <ScenarioSection />
        <ResearchSection />
        <AboutSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;