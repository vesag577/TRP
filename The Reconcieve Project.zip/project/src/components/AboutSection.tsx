import React from 'react';
import { Globe2, HeartPulse, Users2, LineChart } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">About MediGlobal</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our NGO is dedicated to improving healthcare access and outcomes in diverse environments worldwide.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Our Mission</h3>
            <p className="text-gray-600 mb-6">
              MediGlobal works to bridge healthcare gaps across different environments and resource 
              levels by combining research, education, and practical implementation. We believe that 
              everyone deserves access to quality healthcare, regardless of where they live.
            </p>
            <p className="text-gray-600">
              Through our interactive scenarios and community engagement, we aim to share knowledge, 
              gather diverse perspectives, and develop adaptable healthcare solutions that work in 
              any environment.
            </p>
          </div>
          
          <div className="bg-blue-600 p-8 rounded-lg shadow-md text-white">
            <h3 className="text-2xl font-bold mb-4">Our Impact</h3>
            <ul className="space-y-6">
              <li className="flex">
                <div className="mr-4 flex-shrink-0">
                  <Globe2 className="h-8 w-8 text-blue-300" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Global Reach</h4>
                  <p className="text-blue-100">
                    Operating in 24 countries across 5 continents, bringing healthcare 
                    solutions to remote and underserved communities.
                  </p>
                </div>
              </li>
              <li className="flex">
                <div className="mr-4 flex-shrink-0">
                  <HeartPulse className="h-8 w-8 text-blue-300" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Lives Improved</h4>
                  <p className="text-blue-100">
                    Our interventions have directly improved healthcare access for over 
                    2 million people in resource-limited environments.
                  </p>
                </div>
              </li>
              <li className="flex">
                <div className="mr-4 flex-shrink-0">
                  <Users2 className="h-8 w-8 text-blue-300" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Healthcare Workers Trained</h4>
                  <p className="text-blue-100">
                    Trained over 15,000 local healthcare workers in adaptive medical 
                    practices suited to their specific environments.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-gray-800 mb-3">Why We're Different</h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our approach combines practical solutions, community involvement, and continuous learning.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md text-center hover:transform hover:-translate-y-1 transition-transform duration-300">
            <div className="bg-blue-100 p-4 rounded-full inline-flex items-center justify-center mb-4">
              <LineChart className="h-8 w-8 text-blue-600" />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Research-Driven</h4>
            <p className="text-gray-600">
              We combine academic research with field experience to develop practical, 
              evidence-based solutions that work in the real world.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md text-center hover:transform hover:-translate-y-1 transition-transform duration-300">
            <div className="bg-green-100 p-4 rounded-full inline-flex items-center justify-center mb-4">
              <Users2 className="h-8 w-8 text-green-600" />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Community-Centered</h4>
            <p className="text-gray-600">
              We believe that lasting solutions must involve local communities as partners, 
              not just recipients of aid or expertise.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md text-center hover:transform hover:-translate-y-1 transition-transform duration-300">
            <div className="bg-orange-100 p-4 rounded-full inline-flex items-center justify-center mb-4">
              <Globe2 className="h-8 w-8 text-orange-600" />
            </div>
            <h4 className="text-xl font-bold text-gray-800 mb-3">Adaptable Solutions</h4>
            <p className="text-gray-600">
              We recognize that one size doesn't fit all. Our approaches are tailored to 
              the specific contexts and resources available.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;