import React, { useState } from 'react';
import { comments as initialComments } from '../data/comments';
import { Comment } from '../types';
import { MessageSquare } from 'lucide-react';

interface CommentSectionProps {
  scenarioId: string;
}

const CommentSection: React.FC<CommentSectionProps> = ({ scenarioId }) => {
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [newComment, setNewComment] = useState('');
  const [userName, setUserName] = useState('');
  const [showForm, setShowForm] = useState(false);

  const filteredComments = comments.filter(comment => comment.scenarioId === scenarioId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newComment.trim() === '' || userName.trim() === '') return;
    
    const currentDate = new Date();
    const formattedDate = `${currentDate.toLocaleString('default', { month: 'long' })} ${currentDate.getDate()}, ${currentDate.getFullYear()}`;
    
    const comment: Comment = {
      id: Date.now().toString(),
      userName,
      scenarioId,
      text: newComment,
      date: formattedDate
    };
    
    setComments([...comments, comment]);
    setNewComment('');
    setUserName('');
    setShowForm(false);
  };

  return (
    <div className="border-t border-gray-200 pt-8">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-bold text-xl text-gray-800">Community Experiences</h3>
        <button 
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
        >
          Share Your Experience
        </button>
      </div>
      
      {showForm && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6 animate-fadeIn">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="userName" className="block text-sm font-medium text-gray-700 mb-1">
                Your Name
              </label>
              <input
                type="text"
                id="userName"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-4">
              <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-1">
                Your Experience
              </label>
              <textarea
                id="comment"
                rows={4}
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Share your experience with this scenario..."
                required
              ></textarea>
            </div>
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 focus:outline-none"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      )}
      
      {filteredComments.length > 0 ? (
        <div className="space-y-4">
          {filteredComments.map((comment) => (
            <div key={comment.id} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-medium text-gray-800">{comment.userName}</h4>
                <span className="text-sm text-gray-500">{comment.date}</span>
              </div>
              <p className="text-gray-600">{comment.text}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <MessageSquare className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No experiences shared yet. Be the first to share your insights!</p>
        </div>
      )}
    </div>
  );
};

export default CommentSection;