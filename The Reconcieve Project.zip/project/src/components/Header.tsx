import React from 'react';
import { Globe2, Menu, X } from 'lucide-react';
import { useState } from 'react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Globe2 className="h-8 w-8 text-blue-600" />
          <span className="text-xl font-bold text-gray-800">MediGlobal</span>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Home</a>
          <a href="#scenarios" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Scenarios</a>
          <a href="#research" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Research</a>
          <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">About Us</a>
        </nav>
        
        {/* Mobile menu button */}
        <button 
          className="md:hidden text-gray-700 focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
            <a 
              href="#" 
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </a>
            <a 
              href="#scenarios" 
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Scenarios
            </a>
            <a 
              href="#research" 
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Research
            </a>
            <a 
              href="#about" 
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              About Us
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;