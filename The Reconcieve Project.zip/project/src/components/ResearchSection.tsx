import React from 'react';
import { researchItems } from '../data/research';
import { ArrowUpRight, BookOpen } from 'lucide-react';

const ResearchSection: React.FC = () => {
  return (
    <section id="research" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">Latest Research</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our team conducts ongoing research to improve healthcare outcomes in diverse environments.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {researchItems.map((item) => (
            <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src={item.imageUrl} 
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <BookOpen className="h-4 w-4 text-blue-600 mr-2" />
                  <span className="text-sm text-gray-500">{item.date}</span>
                </div>
                <h3 className="font-bold text-xl mb-3 text-gray-800">{item.title}</h3>
                <p className="text-gray-600 mb-4">{item.summary}</p>
                <a 
                  href={item.link} 
                  className="text-blue-600 font-medium inline-flex items-center hover:text-blue-800 transition-colors"
                >
                  Read Full Research
                  <ArrowUpRight className="ml-1 h-4 w-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a 
            href="#" 
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
          >
            View All Research
          </a>
        </div>
      </div>
    </section>
  );
};

export default ResearchSection;