import React from 'react';
import { Scenario } from '../types';
import { ArrowUpRight, Droplets } from 'lucide-react';

interface ScenarioCardProps {
  scenario: Scenario;
  onClick: (scenario: Scenario) => void;
}

const ScenarioCard: React.FC<ScenarioCardProps> = ({ scenario, onClick }) => {
  // Determine badge color based on resource level
  const getBadgeColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg cursor-pointer"
      onClick={() => onClick(scenario)}
    >
      <div className="h-48 overflow-hidden relative">
        <img 
          src={scenario.imageUrl} 
          alt={scenario.title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <div className={`absolute top-3 right-3 ${getBadgeColor(scenario.resourceLevel)} px-2 py-1 rounded-full text-xs font-medium`}>
          {scenario.resourceLevel.charAt(0).toUpperCase() + scenario.resourceLevel.slice(1)} Resources
        </div>
      </div>
      <div className="p-5">
        <div className="flex items-center mb-2 text-sm font-medium">
          <Droplets className="h-4 w-4 mr-1 text-blue-500" />
          <span className="text-gray-600">{scenario.environment}</span>
        </div>
        <h3 className="font-bold text-xl mb-2 text-gray-800">{scenario.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-3">{scenario.description}</p>
        <button 
          className="text-blue-600 font-medium inline-flex items-center hover:text-blue-800 transition-colors"
        >
          Explore Outcomes
          <ArrowUpRight className="ml-1 h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default ScenarioCard;