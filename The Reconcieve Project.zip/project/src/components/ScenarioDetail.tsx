import React, { useState } from 'react';
import { Scenario, Outcome } from '../types';
import { Check, X, ArrowLeft, CheckCircle2, XCircle } from 'lucide-react';
import CommentSection from './CommentSection';

interface ScenarioDetailProps {
  scenario: Scenario;
  onBack: () => void;
}

const ScenarioDetail: React.FC<ScenarioDetailProps> = ({ scenario, onBack }) => {
  const [selectedOutcome, setSelectedOutcome] = useState<Outcome | null>(null);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="h-64 overflow-hidden relative">
        <img 
          src={scenario.imageUrl} 
          alt={scenario.title}
          className="w-full h-full object-cover"
        />
        <button 
          onClick={onBack}
          className="absolute top-4 left-4 bg-white p-2 rounded-full shadow-md hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-gray-700" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
          <h2 className="text-white text-2xl md:text-3xl font-bold">{scenario.title}</h2>
        </div>
      </div>
      
      <div className="p-6">
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <span className="font-medium text-gray-700 mr-2">Environment:</span>
            <span className="text-gray-600">{scenario.environment}</span>
          </div>
          <div className="flex items-center">
            <span className="font-medium text-gray-700 mr-2">Resource Level:</span>
            <span className="capitalize text-gray-600">{scenario.resourceLevel}</span>
          </div>
        </div>
        
        <p className="text-gray-700 mb-8">{scenario.description}</p>
        
        <h3 className="font-bold text-xl mb-4 text-gray-800">Possible Outcomes</h3>
        
        <div className="grid gap-4 mb-8">
          {scenario.outcomes.map((outcome) => (
            <div
              key={outcome.id}
              className={`border rounded-lg p-4 cursor-pointer transition-all ${
                selectedOutcome?.id === outcome.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
              onClick={() => setSelectedOutcome(outcome)}
            >
              <div className="flex justify-between items-start">
                <h4 className="font-semibold text-gray-800 mb-2">{outcome.title}</h4>
                {outcome.success ? (
                  <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
                )}
              </div>
              
              {selectedOutcome?.id === outcome.id && (
                <div className="mt-4 animate-fadeIn">
                  <p className="text-gray-600 mb-4">{outcome.description}</p>
                  <div>
                    <h5 className="font-medium text-gray-700 mb-2">Required Resources:</h5>
                    <ul className="space-y-2">
                      {outcome.requiredResources.map((resource, index) => (
                        <li key={index} className="flex items-center text-sm">
                          {outcome.success ? (
                            <Check className="h-4 w-4 text-green-500 mr-2" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mr-2" />
                          )}
                          <span>{resource}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className={`font-medium ${outcome.success ? 'text-green-600' : 'text-red-600'}`}>
                      {outcome.success 
                        ? 'This approach is viable with the available resources.'
                        : 'This approach is not viable with the available resources.'}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <CommentSection scenarioId={scenario.id} />
      </div>
    </div>
  );
};

export default ScenarioDetail;