import React, { useState } from 'react';
import { scenarios } from '../data/scenarios';
import { Scenario } from '../types';
import ScenarioCard from './ScenarioCard';
import ScenarioDetail from './ScenarioDetail';

const ScenarioSection: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const filteredScenarios = filter === 'all' 
    ? scenarios 
    : scenarios.filter(scenario => 
        scenario.environment.toLowerCase() === filter || 
        scenario.resourceLevel === filter
      );

  const handleScenarioClick = (scenario: Scenario) => {
    setSelectedScenario(scenario);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackClick = () => {
    setSelectedScenario(null);
  };

  return (
    <section id="scenarios" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">Interactive Scenarios</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore how different environments and resource availability impact medical solutions and outcomes.
          </p>
        </div>
        
        {!selectedScenario && (
          <>
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              <button 
                onClick={() => setFilter('all')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'all' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                All Scenarios
              </button>
              <button 
                onClick={() => setFilter('rural')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'rural' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Rural
              </button>
              <button 
                onClick={() => setFilter('urban')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'urban' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Urban
              </button>
              <button 
                onClick={() => setFilter('remote')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'remote' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Remote
              </button>
              <button 
                onClick={() => setFilter('hospital')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'hospital' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Hospital
              </button>
              <button 
                onClick={() => setFilter('low')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'low' 
                    ? 'bg-red-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Low Resources
              </button>
              <button 
                onClick={() => setFilter('medium')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'medium' 
                    ? 'bg-yellow-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                Medium Resources
              </button>
              <button 
                onClick={() => setFilter('high')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === 'high' 
                    ? 'bg-green-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                High Resources
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredScenarios.map((scenario) => (
                <ScenarioCard 
                  key={scenario.id} 
                  scenario={scenario}
                  onClick={handleScenarioClick}
                />
              ))}
            </div>
          </>
        )}
        
        {selectedScenario && (
          <ScenarioDetail scenario={selectedScenario} onBack={handleBackClick} />
        )}
      </div>
    </section>
  );
};

export default ScenarioSection;