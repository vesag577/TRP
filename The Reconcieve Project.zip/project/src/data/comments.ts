import { Comment } from '../types';

export const comments: Comment[] = [
  {
    id: '1',
    userName: 'Dr. Sarah Johnson',
    scenarioId: '1',
    text: 'I\'ve implemented the solar disinfection method in several communities in East Africa with great success. The key is proper education about the time needed for full disinfection.',
    date: 'May 10, 2025'
  },
  {
    id: '2',
    userName: 'Miguel Sanchez',
    scenarioId: '1',
    text: 'We found that combining simple sand filtration with the boiling method produced the best results in our rural clinic in Honduras.',
    date: 'May 8, 2025'
  },
  {
    id: '3',
    userName: 'Aisha Patel',
    scenarioId: '2',
    text: 'The community center approach worked well during the flood response in our city, but coordination between volunteer groups was a challenge we hadn\'t anticipated.',
    date: 'May 5, 2025'
  },
  {
    id: '4',
    userName: 'Dr. James Wilson',
    scenarioId: '3',
    text: 'We\'ve found that consistent training on isolation protocols is just as important as having the right equipment. Staff confidence makes all the difference.',
    date: 'May 2, 2025'
  },
  {
    id: '5',
    userName: 'Nurse Lena Chen',
    scenarioId: '4',
    text: 'The training program for traditional birth attendants made a significant impact, but we still struggled with timely referrals due to transportation issues.',
    date: 'April 28, 2025'
  }
];