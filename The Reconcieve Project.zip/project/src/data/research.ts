import { ResearchItem } from '../types';

export const researchItems: ResearchItem[] = [
  {
    id: '1',
    title: 'Impact of Resource Allocation on Rural Healthcare Outcomes',
    summary: 'This study examined how different resource allocation strategies affect healthcare outcomes in rural communities across three continents.',
    imageUrl: 'https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg',
    date: 'March 15, 2025',
    link: '#'
  },
  {
    id: '2',
    title: 'Effectiveness of Community Health Workers in Low-Resource Settings',
    summary: 'Our team evaluated training programs for community health workers and measured their impact on local health indicators.',
    imageUrl: 'https://images.pexels.com/photos/7088486/pexels-photo-7088486.jpeg',
    date: 'January 22, 2025',
    link: '#'
  },
  {
    id: '3',
    title: 'Innovative Water Purification Methods for Humanitarian Crises',
    summary: 'This research compared five low-cost water purification methods suitable for emergency humanitarian response.',
    imageUrl: 'https://images.pexels.com/photos/2249063/pexels-photo-2249063.jpeg',
    date: 'February 8, 2025',
    link: '#'
  }
];