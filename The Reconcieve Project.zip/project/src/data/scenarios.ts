import { Scenario } from '../types';

export const scenarios: Scenario[] = [
  {
    id: '1',
    title: 'Rural Water Purification',
    description: 'In rural areas with limited clean water access, explore methods to purify water using available resources.',
    environment: 'Rural',
    resourceLevel: 'low',
    imageUrl: 'https://images.pexels.com/photos/7251800/pexels-photo-7251800.jpeg',
    outcomes: [
      {
        id: '1-1',
        title: 'Solar Disinfection',
        description: 'Using plastic bottles and sunlight to disinfect water. Requires minimal resources but takes time.',
        requiredResources: ['Plastic bottles', 'Sunlight'],
        success: true
      },
      {
        id: '1-2',
        title: 'Boiling Method',
        description: 'Boiling water to kill pathogens. Requires fuel source and containers.',
        requiredResources: ['Containers', 'Fuel source'],
        success: true
      },
      {
        id: '1-3',
        title: 'Advanced Filtration',
        description: 'Using commercial water filters for immediate clean water. Not feasible with limited resources.',
        requiredResources: ['Commercial filters', 'Replacement parts'],
        success: false
      }
    ]
  },
  {
    id: '2',
    title: 'Urban First Aid Station',
    description: 'Setting up a first aid station during emergencies in urban areas with moderate access to medical supplies.',
    environment: 'Urban',
    resourceLevel: 'medium',
    imageUrl: 'https://images.pexels.com/photos/3985163/pexels-photo-3985163.jpeg',
    outcomes: [
      {
        id: '2-1',
        title: 'Community Center Setup',
        description: 'Converting community centers into temporary medical stations with basic supplies.',
        requiredResources: ['Basic medical supplies', 'Volunteers', 'Space'],
        success: true
      },
      {
        id: '2-2',
        title: 'Mobile First Aid Units',
        description: 'Creating mobile units to reach different neighborhoods. Requires transportation and coordination.',
        requiredResources: ['Vehicles', 'Fuel', 'Medical supplies', 'Communication devices'],
        success: true
      },
      {
        id: '2-3',
        title: 'Advanced Trauma Center',
        description: 'Attempting to set up advanced trauma care. Not sustainable with medium resources.',
        requiredResources: ['Specialized equipment', 'Trained medical staff', 'Reliable power'],
        success: false
      }
    ]
  },
  {
    id: '3',
    title: 'Infectious Disease Management',
    description: 'Managing the spread of infectious diseases in a well-resourced hospital setting.',
    environment: 'Hospital',
    resourceLevel: 'high',
    imageUrl: 'https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg',
    outcomes: [
      {
        id: '3-1',
        title: 'Isolation Protocols',
        description: 'Implementing proper isolation rooms and procedures to prevent disease spread.',
        requiredResources: ['Negative pressure rooms', 'PPE', 'Trained staff'],
        success: true
      },
      {
        id: '3-2',
        title: 'Treatment Regimens',
        description: 'Administering appropriate medications and supportive care for infected patients.',
        requiredResources: ['Medications', 'Monitoring equipment', 'Medical staff'],
        success: true
      },
      {
        id: '3-3',
        title: 'Community Education',
        description: 'Developing educational materials and outreach to prevent further spread in the community.',
        requiredResources: ['Educational materials', 'Community health workers'],
        success: true
      }
    ]
  },
  {
    id: '4',
    title: 'Maternal Care in Remote Areas',
    description: 'Providing maternal care in remote locations with limited healthcare infrastructure.',
    environment: 'Remote',
    resourceLevel: 'low',
    imageUrl: 'https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg',
    outcomes: [
      {
        id: '4-1',
        title: 'Training Traditional Birth Attendants',
        description: 'Educating local birth attendants on safe practices and when to refer to hospitals.',
        requiredResources: ['Training materials', 'Basic delivery kits'],
        success: true
      },
      {
        id: '4-2',
        title: 'Community Transport System',
        description: 'Organizing community resources to transport women with complications to facilities.',
        requiredResources: ['Vehicles', 'Communication system', 'Volunteer drivers'],
        success: true
      },
      {
        id: '4-3',
        title: 'Satellite Clinic',
        description: 'Attempting to establish a permanent clinic. Unsustainable with limited resources.',
        requiredResources: ['Medical equipment', 'Permanent staff', 'Reliable supply chain'],
        success: false
      }
    ]
  }
];