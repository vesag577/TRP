export interface Scenario {
  id: string;
  title: string;
  description: string;
  environment: string;
  resourceLevel: 'low' | 'medium' | 'high';
  imageUrl: string;
  outcomes: Outcome[];
}

export interface Outcome {
  id: string;
  title: string;
  description: string;
  requiredResources: string[];
  success: boolean;
}

export interface Comment {
  id: string;
  userName: string;
  scenarioId: string;
  text: string;
  date: string;
}

export interface ResearchItem {
  id: string;
  title: string;
  summary: string;
  imageUrl: string;
  date: string;
  link: string;
}